"""
RC4 Implementation
State size: 256 (elements 0-255)
"""

N = 256

def ksa(key):
    S = list(range(N))
    j = 0
    for i in range(N):
        j = (j + S[i] + key[i % len(key)]) % N
        S[i], S[j] = S[j], S[i]
    return S

def prga(S_after_ksa, M):
    Z = []

    S = S_after_ksa[:]  # Work on a copy

    i = 0
    j = 0

    for _ in range(M):
        # First keystream word generation
        i = (i + 1) % N
        j = (j + S[i]) % N
        S[i], S[j] = S[j], S[i]
        
        Z1 = S[(S[i] + S[j]) % N]
        Z.append(Z1)

    return Z
