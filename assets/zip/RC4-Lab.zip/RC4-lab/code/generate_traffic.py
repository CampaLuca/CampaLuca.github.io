import csv
import random
from toy_rc4 import ksa, prga
 

N = 256
IV_LEN = 3
SECRET_LEN = 4
NUM_PACKETS = 500000

# This is the secret key that the FMS attack will try to recover.
SECRET_ROOT_KEY = [?, ?, ?, ?]  # Replace with the secret key values (4 bytes) you want to use for testing. Values must be in the range 0-255. For example, [1, 2, 3, 4] or [42, 99, 123, 200].


def generate_traffic(output_csv_file):
    """Generates simulated intercepted traffic and saves it to a CSV file."""
    with open(output_csv_file, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['iv0', 'iv1', 'iv2', 'Z1'])  
    
        for _ in range(NUM_PACKETS):
            iv = [random.randint(3, 6), N-1, random.randint(0, N - 1)] # as you see here, all generated IVs are weak IVs. You can also try to generate some random IVs, but the FMS attack will require more than 500000 packets. 
            ###### How many packets do you need in such a case? You can try to find out by yourself.
            key = iv + SECRET_ROOT_KEY
            S_after_ksa = ksa(key)
            Z1 = prga(S_after_ksa, 1)[0]
            writer.writerow(iv + [Z1]) 

if __name__ == '__main__':
    generate_traffic('intercepted_traffic.csv')
    print(f"Generated {NUM_PACKETS} records in 'intercepted_traffic.csv' with secret key {SECRET_ROOT_KEY}.")