import sys
from scapy.all import DNS, DNSQR, IP, sr1, UDP

def my_dig(domain, record_type, server_ip):
    # Constructing the IP and UDP packets
    ip_pkt = IP(dst=server_ip)
    udp_pkt = UDP(dport=53)
    
    # Constructing the DNS query
    dns_pkt = DNS(rd=1, qd=DNSQR(qname=domain, qtype=record_type))
    
    # Send the packet and receive the first answer
    query = ip_pkt / udp_pkt / dns_pkt
    res = sr1(query, verbose=0, timeout=2)
    
    if res and res.haslayer(DNS):
        print(f";; QUESTION SECTION:")
        print(f";{res[DNS].qd.qname.decode()} \t\t IN \t {record_type}")
        
        print("\n;; ANSWER SECTION:")
        for i in range(res[DNS].ancount):
            ans = res[DNS].an[i]
            
            # Extract rdata safely depending on the type of record
            rdata = ans.rdata
            if isinstance(rdata, bytes):
                try:
                    rdata = rdata.decode()
                except UnicodeDecodeError:
                    rdata = str(rdata)
            elif isinstance(rdata, list):  # Often for TXT records
                rdata = b"".join(rdata).decode(errors='ignore')
                
            # Get the string representation of the record type
            rtype = ans.get_field('type').i2repr(ans, ans.type) if hasattr(ans, 'get_field') else ans.type
            
            print(f"{ans.rrname.decode()} \t {ans.ttl} \t IN \t {rtype} \t {rdata}")
    else:
        print("No response or timeout.")

if __name__ == "__main__":
    if len(sys.argv) not in [3, 4]:
        print("Usage: python3 my_dig.py <domain> [record_type] <resolver_ip>")
        print("Supported common types: A, AAAA, MX, NS, TXT, CNAME, SOA")
        sys.exit(1)
        
    if len(sys.argv) == 3:
        my_dig(sys.argv[1], "A", sys.argv[2])
    else:
        my_dig(sys.argv[1], sys.argv[2].upper(), sys.argv[3])
